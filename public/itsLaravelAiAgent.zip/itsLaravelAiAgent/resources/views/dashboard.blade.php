<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="0;url=/chat">
    <title>Redirecting...</title>
</head>
<body>
    <p>Redirecting to AI Chat...</p>
    <script>window.location.href = '/chat';</script>
</body>
</html>